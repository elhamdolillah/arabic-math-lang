global _start
section .bss
    vars resq 256
    num_buf resb 32
    read_buf resb 256
    arena_ptr resq 1
    arena_mem resb 262144

section .text
arena_alloc:
    mov rax, [arena_ptr]
    add rdi, 15
    and rdi, -16
    add [arena_ptr], rdi
    ret

print_int:
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    mov rbx, 10
    mov rcx, 0
    lea rdi, [num_buf + 31]
.piloop:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rdi
    mov [rdi], dl
    inc rcx
    test rax, rax
    jnz .piloop
    mov rsi, rdi
    mov byte [rsi + rcx], 10
    inc rcx
    mov rdi, 1
    mov rax, 1
    mov rdx, rcx
    syscall
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
    ret

print_str:
    push rax
    push rdx
    push rsi
    push rdi
    mov rsi, rax
    add rsi, 8
    mov rdx, [rax]
    mov rdi, 1
    mov rax, 1
    syscall
    mov rsi, nl_ptr
    mov rdx, 1
    mov rdi, 1
    mov rax, 1
    syscall
    pop rdi
    pop rsi
    pop rdx
    pop rax
    ret

section .data
nl_ptr: db 10
section .text

_start:
    lea rax, [arena_mem]
    mov [arena_ptr], rax

    xor rcx, rcx
.rd_loop_1:
    lea rsi, [read_buf + rcx]
    xor rdi, rdi
    mov rdx, 1
    xor rax, rax
    push rcx
    syscall
    pop rcx
    test rax, rax
    jz .rd_end_1
    mov al, [read_buf + rcx]
    cmp al, 10
    je .rd_end_1
    inc rcx
    jmp .rd_loop_1
.rd_end_1:
    mov rax, rcx
    add rax, 8
    mov rdi, rax
    call arena_alloc
    mov [rax], rcx
    push rax
    push rcx
    lea rsi, [read_buf]
    lea rdi, [rax + 8]
.rd_copy_1:
    test rcx, rcx
    jz .rd_cdone_1
    mov al, [rsi]
    mov [rdi], al
    inc rsi
    inc rdi
    dec rcx
    jmp .rd_copy_1
.rd_cdone_1:
    pop rcx
    pop rax
    mov [vars + 0], rax
    xor rcx, rcx
.rd_loop_2:
    lea rsi, [read_buf + rcx]
    xor rdi, rdi
    mov rdx, 1
    xor rax, rax
    push rcx
    syscall
    pop rcx
    test rax, rax
    jz .rd_end_2
    mov al, [read_buf + rcx]
    cmp al, 10
    je .rd_end_2
    inc rcx
    jmp .rd_loop_2
.rd_end_2:
    mov rax, rcx
    add rax, 8
    mov rdi, rax
    call arena_alloc
    mov [rax], rcx
    push rax
    push rcx
    lea rsi, [read_buf]
    lea rdi, [rax + 8]
.rd_copy_2:
    test rcx, rcx
    jz .rd_cdone_2
    mov al, [rsi]
    mov [rdi], al
    inc rsi
    inc rdi
    dec rcx
    jmp .rd_copy_2
.rd_cdone_2:
    pop rcx
    pop rax
    mov [vars + 8], rax
    xor rcx, rcx
.rd_loop_3:
    lea rsi, [read_buf + rcx]
    xor rdi, rdi
    mov rdx, 1
    xor rax, rax
    push rcx
    syscall
    pop rcx
    test rax, rax
    jz .rd_end_3
    mov al, [read_buf + rcx]
    cmp al, 10
    je .rd_end_3
    inc rcx
    jmp .rd_loop_3
.rd_end_3:
    mov rax, rcx
    add rax, 8
    mov rdi, rax
    call arena_alloc
    mov [rax], rcx
    push rax
    push rcx
    lea rsi, [read_buf]
    lea rdi, [rax + 8]
.rd_copy_3:
    test rcx, rcx
    jz .rd_cdone_3
    mov al, [rsi]
    mov [rdi], al
    inc rsi
    inc rdi
    dec rcx
    jmp .rd_copy_3
.rd_cdone_3:
    pop rcx
    pop rax
    mov [vars + 16], rax
    xor rcx, rcx
.rd_loop_4:
    lea rsi, [read_buf + rcx]
    xor rdi, rdi
    mov rdx, 1
    xor rax, rax
    push rcx
    syscall
    pop rcx
    test rax, rax
    jz .rd_end_4
    mov al, [read_buf + rcx]
    cmp al, 10
    je .rd_end_4
    inc rcx
    jmp .rd_loop_4
.rd_end_4:
    mov rax, rcx
    add rax, 8
    mov rdi, rax
    call arena_alloc
    mov [rax], rcx
    push rax
    push rcx
    lea rsi, [read_buf]
    lea rdi, [rax + 8]
.rd_copy_4:
    test rcx, rcx
    jz .rd_cdone_4
    mov al, [rsi]
    mov [rdi], al
    inc rsi
    inc rdi
    dec rcx
    jmp .rd_copy_4
.rd_cdone_4:
    pop rcx
    pop rax
    mov [vars + 24], rax
    mov rax, [vars + 0]
    mov rax, [rax]
    mov [vars + 32], rax
    mov rax, [vars + 8]
    mov rax, [rax]
    mov [vars + 40], rax
    mov rax, [vars + 16]
    mov rax, [rax]
    mov [vars + 48], rax
    mov rax, 0
    mov [vars + 56], rax
    mov rax, 0
    mov [vars + 64], rax
    mov rax, 0
    mov [vars + 72], rax
    mov rax, [vars + 0]
    push rax
    mov rax, 1
    pop rbx
    mov rcx, rax
    mov rax, [rbx]
    cmp rcx, rax
    jge .ch_err_1
    movzx rax, byte [rbx + rcx + 8]
    jmp .ch_ok_1
.ch_err_1:
    mov rax, 60
    mov rdi, 1
    syscall
.ch_ok_1:
    mov [vars + 80], rax
    mov rax, 7
    mov [vars + 88], rax
    mov rax, 0
    mov [vars + 96], rax
    mov rax, 1
    mov [vars + 104], rax
.while_1:
    mov rax, [vars + 104]
    push rax
    mov rax, 1
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    cmp rax, 0
    je .wend_1
    mov rax, [vars + 88]
    push rax
    mov rax, [vars + 32]
    pop rbx
    cmp rbx, rax
    mov rax, 0
    setl al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_1
    mov rax, [vars + 0]
    push rax
    mov rax, [vars + 88]
    pop rbx
    mov rcx, rax
    mov rax, [rbx]
    cmp rcx, rax
    jge .ch_err_2
    movzx rax, byte [rbx + rcx + 8]
    jmp .ch_ok_2
.ch_err_2:
    mov rax, 60
    mov rdi, 1
    syscall
.ch_ok_2:
    jmp .end_1
.else_1:
    mov rax, 32
.end_1:
    mov [vars + 112], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_2
    mov rax, [vars + 96]
    push rax
    mov rax, 10
    pop rbx
    imul rax, rbx
    push rax
    mov rax, [vars + 112]
    pop rbx
    add rax, rbx
    push rax
    mov rax, 48
    pop rbx
    sub rbx, rax
    mov rax, rbx
    jmp .end_2
.else_2:
    mov rax, [vars + 96]
.end_2:
    mov [vars + 96], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_3
    mov rax, [vars + 88]
    push rax
    mov rax, 1
    pop rbx
    add rax, rbx
    jmp .end_3
.else_3:
    mov rax, [vars + 88]
.end_3:
    mov [vars + 88], rax
    jmp .while_1
.wend_1:
    mov rax, [vars + 80]
    push rax
    mov rax, 163
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_4
    mov rax, [vars + 96]
    jmp .end_4
.else_4:
    mov rax, [vars + 56]
.end_4:
    mov [vars + 56], rax
    mov rax, [vars + 80]
    push rax
    mov rax, 168
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_5
    mov rax, [vars + 96]
    jmp .end_5
.else_5:
    mov rax, [vars + 64]
.end_5:
    mov [vars + 64], rax
    mov rax, [vars + 80]
    push rax
    mov rax, 172
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_6
    mov rax, [vars + 96]
    jmp .end_6
.else_6:
    mov rax, [vars + 72]
.end_6:
    mov [vars + 72], rax
    mov rax, [vars + 8]
    push rax
    mov rax, 1
    pop rbx
    mov rcx, rax
    mov rax, [rbx]
    cmp rcx, rax
    jge .ch_err_3
    movzx rax, byte [rbx + rcx + 8]
    jmp .ch_ok_3
.ch_err_3:
    mov rax, 60
    mov rdi, 1
    syscall
.ch_ok_3:
    mov [vars + 120], rax
    mov rax, 7
    mov [vars + 88], rax
    mov rax, 0
    mov [vars + 96], rax
    mov rax, 1
    mov [vars + 104], rax
.while_2:
    mov rax, [vars + 104]
    push rax
    mov rax, 1
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    cmp rax, 0
    je .wend_2
    mov rax, [vars + 88]
    push rax
    mov rax, [vars + 40]
    pop rbx
    cmp rbx, rax
    mov rax, 0
    setl al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_7
    mov rax, [vars + 8]
    push rax
    mov rax, [vars + 88]
    pop rbx
    mov rcx, rax
    mov rax, [rbx]
    cmp rcx, rax
    jge .ch_err_4
    movzx rax, byte [rbx + rcx + 8]
    jmp .ch_ok_4
.ch_err_4:
    mov rax, 60
    mov rdi, 1
    syscall
.ch_ok_4:
    jmp .end_7
.else_7:
    mov rax, 32
.end_7:
    mov [vars + 112], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_8
    mov rax, [vars + 96]
    push rax
    mov rax, 10
    pop rbx
    imul rax, rbx
    push rax
    mov rax, [vars + 112]
    pop rbx
    add rax, rbx
    push rax
    mov rax, 48
    pop rbx
    sub rbx, rax
    mov rax, rbx
    jmp .end_8
.else_8:
    mov rax, [vars + 96]
.end_8:
    mov [vars + 96], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_9
    mov rax, [vars + 88]
    push rax
    mov rax, 1
    pop rbx
    add rax, rbx
    jmp .end_9
.else_9:
    mov rax, [vars + 88]
.end_9:
    mov [vars + 88], rax
    jmp .while_2
.wend_2:
    mov rax, [vars + 120]
    push rax
    mov rax, 163
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_10
    mov rax, [vars + 96]
    jmp .end_10
.else_10:
    mov rax, [vars + 56]
.end_10:
    mov [vars + 56], rax
    mov rax, [vars + 120]
    push rax
    mov rax, 168
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_11
    mov rax, [vars + 96]
    jmp .end_11
.else_11:
    mov rax, [vars + 64]
.end_11:
    mov [vars + 64], rax
    mov rax, [vars + 120]
    push rax
    mov rax, 172
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_12
    mov rax, [vars + 96]
    jmp .end_12
.else_12:
    mov rax, [vars + 72]
.end_12:
    mov [vars + 72], rax
    mov rax, [vars + 16]
    push rax
    mov rax, 1
    pop rbx
    mov rcx, rax
    mov rax, [rbx]
    cmp rcx, rax
    jge .ch_err_5
    movzx rax, byte [rbx + rcx + 8]
    jmp .ch_ok_5
.ch_err_5:
    mov rax, 60
    mov rdi, 1
    syscall
.ch_ok_5:
    mov [vars + 128], rax
    mov rax, 7
    mov [vars + 88], rax
    mov rax, 0
    mov [vars + 96], rax
    mov rax, 1
    mov [vars + 136], rax
.while_3:
    mov rax, [vars + 136]
    push rax
    mov rax, 1
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    cmp rax, 0
    je .wend_3
    mov rax, [vars + 88]
    push rax
    mov rax, [vars + 48]
    pop rbx
    cmp rbx, rax
    mov rax, 0
    setl al
    mov [vars + 136], rax
    mov rax, [vars + 136]
    cmp rax, 0
    je .else_13
    mov rax, [vars + 16]
    push rax
    mov rax, [vars + 88]
    pop rbx
    mov rcx, rax
    mov rax, [rbx]
    cmp rcx, rax
    jge .ch_err_6
    movzx rax, byte [rbx + rcx + 8]
    jmp .ch_ok_6
.ch_err_6:
    mov rax, 60
    mov rdi, 1
    syscall
.ch_ok_6:
    jmp .end_13
.else_13:
    mov rax, 32
.end_13:
    mov [vars + 112], rax
    mov rax, [vars + 136]
    cmp rax, 0
    je .else_14
    mov rax, [vars + 96]
    push rax
    mov rax, 10
    pop rbx
    imul rax, rbx
    push rax
    mov rax, [vars + 112]
    pop rbx
    add rax, rbx
    push rax
    mov rax, 48
    pop rbx
    sub rbx, rax
    mov rax, rbx
    jmp .end_14
.else_14:
    mov rax, [vars + 96]
.end_14:
    mov [vars + 96], rax
    mov rax, [vars + 136]
    cmp rax, 0
    je .else_15
    mov rax, [vars + 88]
    push rax
    mov rax, 1
    pop rbx
    add rax, rbx
    jmp .end_15
.else_15:
    mov rax, [vars + 88]
.end_15:
    mov [vars + 88], rax
    jmp .while_3
.wend_3:
    mov rax, [vars + 128]
    push rax
    mov rax, 163
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_16
    mov rax, [vars + 96]
    jmp .end_16
.else_16:
    mov rax, [vars + 56]
.end_16:
    mov [vars + 56], rax
    mov rax, [vars + 128]
    push rax
    mov rax, 168
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_17
    mov rax, [vars + 96]
    jmp .end_17
.else_17:
    mov rax, [vars + 64]
.end_17:
    mov [vars + 64], rax
    mov rax, [vars + 128]
    push rax
    mov rax, 172
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_18
    mov rax, [vars + 96]
    jmp .end_18
.else_18:
    mov rax, [vars + 72]
.end_18:
    mov [vars + 72], rax
    mov rax, [vars + 24]
    push rax
    mov rax, 5
    pop rbx
    mov rcx, rax
    mov rax, [rbx]
    cmp rcx, rax
    jge .ch_err_7
    movzx rax, byte [rbx + rcx + 8]
    jmp .ch_ok_7
.ch_err_7:
    mov rax, 60
    mov rdi, 1
    syscall
.ch_ok_7:
    mov [vars + 144], rax
    mov rax, [vars + 24]
    push rax
    mov rax, 7
    pop rbx
    mov rcx, rax
    mov rax, [rbx]
    cmp rcx, rax
    jge .ch_err_8
    movzx rax, byte [rbx + rcx + 8]
    jmp .ch_ok_8
.ch_err_8:
    mov rax, 60
    mov rdi, 1
    syscall
.ch_ok_8:
    mov [vars + 152], rax
    mov rax, [vars + 24]
    push rax
    mov rax, 10
    pop rbx
    mov rcx, rax
    mov rax, [rbx]
    cmp rcx, rax
    jge .ch_err_9
    movzx rax, byte [rbx + rcx + 8]
    jmp .ch_ok_9
.ch_err_9:
    mov rax, 60
    mov rdi, 1
    syscall
.ch_ok_9:
    mov [vars + 160], rax
    mov rax, [vars + 24]
    push rax
    mov rax, 12
    pop rbx
    mov rcx, rax
    mov rax, [rbx]
    cmp rcx, rax
    jge .ch_err_10
    movzx rax, byte [rbx + rcx + 8]
    jmp .ch_ok_10
.ch_err_10:
    mov rax, 60
    mov rdi, 1
    syscall
.ch_ok_10:
    mov [vars + 168], rax
    mov rax, [vars + 24]
    push rax
    mov rax, 15
    pop rbx
    mov rcx, rax
    mov rax, [rbx]
    cmp rcx, rax
    jge .ch_err_11
    movzx rax, byte [rbx + rcx + 8]
    jmp .ch_ok_11
.ch_err_11:
    mov rax, 60
    mov rdi, 1
    syscall
.ch_ok_11:
    mov [vars + 176], rax
    mov rax, 0
    mov [vars + 184], rax
    mov rax, [vars + 144]
    push rax
    mov rax, 163
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_19
    mov rax, [vars + 56]
    jmp .end_19
.else_19:
    mov rax, [vars + 184]
.end_19:
    mov [vars + 184], rax
    mov rax, [vars + 144]
    push rax
    mov rax, 168
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_20
    mov rax, [vars + 64]
    jmp .end_20
.else_20:
    mov rax, [vars + 184]
.end_20:
    mov [vars + 184], rax
    mov rax, [vars + 144]
    push rax
    mov rax, 172
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_21
    mov rax, [vars + 72]
    jmp .end_21
.else_21:
    mov rax, [vars + 184]
.end_21:
    mov [vars + 184], rax
    mov rax, 0
    mov [vars + 192], rax
    mov rax, [vars + 160]
    push rax
    mov rax, 163
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_22
    mov rax, [vars + 56]
    jmp .end_22
.else_22:
    mov rax, [vars + 192]
.end_22:
    mov [vars + 192], rax
    mov rax, [vars + 160]
    push rax
    mov rax, 168
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_23
    mov rax, [vars + 64]
    jmp .end_23
.else_23:
    mov rax, [vars + 192]
.end_23:
    mov [vars + 192], rax
    mov rax, [vars + 160]
    push rax
    mov rax, 172
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_24
    mov rax, [vars + 72]
    jmp .end_24
.else_24:
    mov rax, [vars + 192]
.end_24:
    mov [vars + 192], rax
    mov rax, 0
    mov [vars + 200], rax
    mov rax, [vars + 176]
    push rax
    mov rax, 163
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_25
    mov rax, [vars + 56]
    jmp .end_25
.else_25:
    mov rax, [vars + 200]
.end_25:
    mov [vars + 200], rax
    mov rax, [vars + 176]
    push rax
    mov rax, 168
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_26
    mov rax, [vars + 64]
    jmp .end_26
.else_26:
    mov rax, [vars + 200]
.end_26:
    mov [vars + 200], rax
    mov rax, [vars + 176]
    push rax
    mov rax, 172
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_27
    mov rax, [vars + 72]
    jmp .end_27
.else_27:
    mov rax, [vars + 200]
.end_27:
    mov [vars + 200], rax
    mov rdi, 17
    call arena_alloc
    mov qword [rax], 9
    mov byte [rax + 8], 109
    mov byte [rax + 9], 111
    mov byte [rax + 10], 118
    mov byte [rax + 11], 32
    mov byte [rax + 12], 114
    mov byte [rax + 13], 97
    mov byte [rax + 14], 120
    mov byte [rax + 15], 44
    mov byte [rax + 16], 32
    push rax
    mov rax, [vars + 184]
    mov rbx, 10
    mov rcx, 0
    lea rdi, [num_buf + 31]
.nts_5:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rdi
    mov [rdi], dl
    inc rcx
    test rax, rax
    jnz .nts_5
    push rdi
    push rcx
    mov rax, rcx
    add rax, 8
    mov rdi, rax
    call arena_alloc
    pop rcx
    mov [rax], rcx
    pop rsi
    push rax
    lea rdi, [rax + 8]
.ntc_5:
    test rcx, rcx
    jz .ntd_5
    mov al, [rsi]
    mov [rdi], al
    inc rsi
    inc rdi
    dec rcx
    jmp .ntc_5
.ntd_5:
    pop rax
    mov r11, rax
    pop r10
    push r10
    push r11
    mov rax, [r10]
    add rax, [r11]
    add rax, 8
    mov rdi, rax
    call arena_alloc
    mov r12, rax
    mov rax, [r10]
    add rax, [r11]
    mov [r12], rax
    mov rax, [r10]
    lea rsi, [r10 + 8]
    lea rdi, [r12 + 8]
.cpy1_6:
    test rax, rax
    jz .c1d_6
    mov cl, [rsi]
    mov [rdi], cl
    inc rsi
    inc rdi
    dec rax
    jmp .cpy1_6
.c1d_6:
    mov rax, [r11]
    lea rsi, [r11 + 8]
.cpy2_6:
    test rax, rax
    jz .c2d_6
    mov cl, [rsi]
    mov [rdi], cl
    inc rsi
    inc rdi
    dec rax
    jmp .cpy2_6
.c2d_6:
    pop r11
    pop r10
    mov rax, r12
    call print_str
    mov rdi, 11
    call arena_alloc
    mov qword [rax], 3
    mov byte [rax + 8], 97
    mov byte [rax + 9], 100
    mov byte [rax + 10], 100
    mov [vars + 208], rax
    mov rax, [vars + 152]
    push rax
    mov rax, 45
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_28
    mov rdi, 11
    call arena_alloc
    mov qword [rax], 3
    mov byte [rax + 8], 115
    mov byte [rax + 9], 117
    mov byte [rax + 10], 98
    jmp .end_28
.else_28:
    mov rax, [vars + 208]
.end_28:
    mov [vars + 208], rax
    mov rax, [vars + 152]
    push rax
    mov rax, 42
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_29
    mov rdi, 12
    call arena_alloc
    mov qword [rax], 4
    mov byte [rax + 8], 105
    mov byte [rax + 9], 109
    mov byte [rax + 10], 117
    mov byte [rax + 11], 108
    jmp .end_29
.else_29:
    mov rax, [vars + 208]
.end_29:
    mov [vars + 208], rax
    mov rax, [vars + 208]
    push rax
    mov rdi, 14
    call arena_alloc
    mov qword [rax], 6
    mov byte [rax + 8], 32
    mov byte [rax + 9], 114
    mov byte [rax + 10], 97
    mov byte [rax + 11], 120
    mov byte [rax + 12], 44
    mov byte [rax + 13], 32
    mov r11, rax
    pop r10
    push r10
    push r11
    mov rax, [r10]
    add rax, [r11]
    add rax, 8
    mov rdi, rax
    call arena_alloc
    mov r12, rax
    mov rax, [r10]
    add rax, [r11]
    mov [r12], rax
    mov rax, [r10]
    lea rsi, [r10 + 8]
    lea rdi, [r12 + 8]
.cpy1_7:
    test rax, rax
    jz .c1d_7
    mov cl, [rsi]
    mov [rdi], cl
    inc rsi
    inc rdi
    dec rax
    jmp .cpy1_7
.c1d_7:
    mov rax, [r11]
    lea rsi, [r11 + 8]
.cpy2_7:
    test rax, rax
    jz .c2d_7
    mov cl, [rsi]
    mov [rdi], cl
    inc rsi
    inc rdi
    dec rax
    jmp .cpy2_7
.c2d_7:
    pop r11
    pop r10
    mov rax, r12
    push rax
    mov rax, [vars + 192]
    mov rbx, 10
    mov rcx, 0
    lea rdi, [num_buf + 31]
.nts_8:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rdi
    mov [rdi], dl
    inc rcx
    test rax, rax
    jnz .nts_8
    push rdi
    push rcx
    mov rax, rcx
    add rax, 8
    mov rdi, rax
    call arena_alloc
    pop rcx
    mov [rax], rcx
    pop rsi
    push rax
    lea rdi, [rax + 8]
.ntc_8:
    test rcx, rcx
    jz .ntd_8
    mov al, [rsi]
    mov [rdi], al
    inc rsi
    inc rdi
    dec rcx
    jmp .ntc_8
.ntd_8:
    pop rax
    mov r11, rax
    pop r10
    push r10
    push r11
    mov rax, [r10]
    add rax, [r11]
    add rax, 8
    mov rdi, rax
    call arena_alloc
    mov r12, rax
    mov rax, [r10]
    add rax, [r11]
    mov [r12], rax
    mov rax, [r10]
    lea rsi, [r10 + 8]
    lea rdi, [r12 + 8]
.cpy1_9:
    test rax, rax
    jz .c1d_9
    mov cl, [rsi]
    mov [rdi], cl
    inc rsi
    inc rdi
    dec rax
    jmp .cpy1_9
.c1d_9:
    mov rax, [r11]
    lea rsi, [r11 + 8]
.cpy2_9:
    test rax, rax
    jz .c2d_9
    mov cl, [rsi]
    mov [rdi], cl
    inc rsi
    inc rdi
    dec rax
    jmp .cpy2_9
.c2d_9:
    pop r11
    pop r10
    mov rax, r12
    call print_str
    mov rdi, 11
    call arena_alloc
    mov qword [rax], 3
    mov byte [rax + 8], 97
    mov byte [rax + 9], 100
    mov byte [rax + 10], 100
    mov [vars + 208], rax
    mov rax, [vars + 168]
    push rax
    mov rax, 45
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_30
    mov rdi, 11
    call arena_alloc
    mov qword [rax], 3
    mov byte [rax + 8], 115
    mov byte [rax + 9], 117
    mov byte [rax + 10], 98
    jmp .end_30
.else_30:
    mov rax, [vars + 208]
.end_30:
    mov [vars + 208], rax
    mov rax, [vars + 168]
    push rax
    mov rax, 42
    pop rbx
    cmp rbx, rax
    mov rax, 0
    sete al
    mov [vars + 104], rax
    mov rax, [vars + 104]
    cmp rax, 0
    je .else_31
    mov rdi, 12
    call arena_alloc
    mov qword [rax], 4
    mov byte [rax + 8], 105
    mov byte [rax + 9], 109
    mov byte [rax + 10], 117
    mov byte [rax + 11], 108
    jmp .end_31
.else_31:
    mov rax, [vars + 208]
.end_31:
    mov [vars + 208], rax
    mov rax, [vars + 208]
    push rax
    mov rdi, 14
    call arena_alloc
    mov qword [rax], 6
    mov byte [rax + 8], 32
    mov byte [rax + 9], 114
    mov byte [rax + 10], 97
    mov byte [rax + 11], 120
    mov byte [rax + 12], 44
    mov byte [rax + 13], 32
    mov r11, rax
    pop r10
    push r10
    push r11
    mov rax, [r10]
    add rax, [r11]
    add rax, 8
    mov rdi, rax
    call arena_alloc
    mov r12, rax
    mov rax, [r10]
    add rax, [r11]
    mov [r12], rax
    mov rax, [r10]
    lea rsi, [r10 + 8]
    lea rdi, [r12 + 8]
.cpy1_10:
    test rax, rax
    jz .c1d_10
    mov cl, [rsi]
    mov [rdi], cl
    inc rsi
    inc rdi
    dec rax
    jmp .cpy1_10
.c1d_10:
    mov rax, [r11]
    lea rsi, [r11 + 8]
.cpy2_10:
    test rax, rax
    jz .c2d_10
    mov cl, [rsi]
    mov [rdi], cl
    inc rsi
    inc rdi
    dec rax
    jmp .cpy2_10
.c2d_10:
    pop r11
    pop r10
    mov rax, r12
    push rax
    mov rax, [vars + 200]
    mov rbx, 10
    mov rcx, 0
    lea rdi, [num_buf + 31]
.nts_11:
    xor rdx, rdx
    div rbx
    add dl, '0'
    dec rdi
    mov [rdi], dl
    inc rcx
    test rax, rax
    jnz .nts_11
    push rdi
    push rcx
    mov rax, rcx
    add rax, 8
    mov rdi, rax
    call arena_alloc
    pop rcx
    mov [rax], rcx
    pop rsi
    push rax
    lea rdi, [rax + 8]
.ntc_11:
    test rcx, rcx
    jz .ntd_11
    mov al, [rsi]
    mov [rdi], al
    inc rsi
    inc rdi
    dec rcx
    jmp .ntc_11
.ntd_11:
    pop rax
    mov r11, rax
    pop r10
    push r10
    push r11
    mov rax, [r10]
    add rax, [r11]
    add rax, 8
    mov rdi, rax
    call arena_alloc
    mov r12, rax
    mov rax, [r10]
    add rax, [r11]
    mov [r12], rax
    mov rax, [r10]
    lea rsi, [r10 + 8]
    lea rdi, [r12 + 8]
.cpy1_12:
    test rax, rax
    jz .c1d_12
    mov cl, [rsi]
    mov [rdi], cl
    inc rsi
    inc rdi
    dec rax
    jmp .cpy1_12
.c1d_12:
    mov rax, [r11]
    lea rsi, [r11 + 8]
.cpy2_12:
    test rax, rax
    jz .c2d_12
    mov cl, [rsi]
    mov [rdi], cl
    inc rsi
    inc rdi
    dec rax
    jmp .cpy2_12
.c2d_12:
    pop r11
    pop r10
    mov rax, r12
    call print_str

    mov rax, 60
    xor rdi, rdi
    syscall
